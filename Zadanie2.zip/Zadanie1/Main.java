package Zadanie1;

import java.time.LocalDateTime;

public class Main {
    public static void main(String[] args) {
        StringContainer st = new StringContainer("\\d{2}[-]\\d{3}");
        //StringContainer st2 = new StringContainer("\\d{2[-]\\d{3}"); // InvalidStringContainerPatternException
        System.out.println("Pattern: " + st.getPattern());

        st.add("02-495");
        st.add("01-120");
        st.add("05-123");
        st.add("00-000");
        // st.add("Ala ma kota"); // invalidStringContainerValueException

        System.out.println("\nWszystkie dane:");
        for (int i = 0; i < st.getSize(); i++) {
            System.out.println(st.get(i));
        }

        st.remove(0);
        st.remove("00-000");

        System.out.println("\nPo usunieciu:");
        for (int i = 0; i < st.getSize(); i++) {
            System.out.println(st.get(i));
        }

        StringContainer st3 = new StringContainer("\\d{2}[-]\\d{3}", true);
        st3.add("00-000");
        // st3.add("00-000"); // DuplicatedElementOnListException

        System.out.println("\nSprawdzanie daty dodania elementu:");
        System.out.println(st + ", Element: " + st.get(0) + ", Data i godzina dodania: " + st.get(0).getDate());

        System.out.println("\nMetoda getDataBetween:");
        StringContainer stBetween = st.getDataBetween(LocalDateTime.now().minusDays(1), LocalDateTime.now().plusDays(1));
        for (int i = 0; i < stBetween.getSize(); i++) {
            System.out.println(stBetween.get(i));
        }

        System.out.println("\nWersja z nullami: ");
        StringContainer stBetween2 = st.getDataBetween(null, null);
        for (int i = 0; i < stBetween2.getSize(); i++) {
            System.out.println(stBetween2.get(i));
        }

        StringContainer stBetween3 = st.getDataBetween(null, LocalDateTime.now().minusMinutes(1));
        for (int i = 0; i < stBetween3.getSize(); i++) {
            System.out.println(stBetween3.get(i));
        }

        StringContainer stBetween4 = st.getDataBetween(LocalDateTime.now().plusMinutes(1), null);
        for (int i = 0; i < stBetween4.getSize(); i++) {
            System.out.println(stBetween4.get(i));
        }

        st.storeToFile("C:\\Users\\aware\\IdeaProjects\\Kurs\\Test3Poprawka\\src\\Zadanie1\\plik");
        StringContainer fromFile = StringContainer.fromFile("C:\\Users\\aware\\IdeaProjects\\Kurs\\Test3Poprawka\\src\\Zadanie1\\plik");

        System.out.println("\nWartosci zapisane do StringContainer fromFile z pliku postalCodes.txt: ");
        for (int i = 0; i < fromFile.getSize(); i++) {
            System.out.println(fromFile.get(i));
        }
    }
}