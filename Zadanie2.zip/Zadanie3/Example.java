package Zadanie3;

public class Example {
    public static void main(String[] args) {
        int x = 5;
        String name = "John";
        double salary = 1000.50;
        boolean isActive = true;

        // Inne operacje...

        String anotherName = "Alice";
        int y = 10;
        char grade = 'A';
        boolean isAdmin = false;
        int yy = 10;
        int yyy = 10;
        int yyyy = 10;int yyyyy = 10;  boolean aaaa = false;


        String anotherName2 = "int yyyy = 10;int yyyyy = 10;  boolean aaaa = false;";
        String anotherName3 = "int yyyy = 10;int yyyyy = 10;  boolean aaaa = false;";

//        int yyyy = 10;int yyyyy = 10;  boolean aaaa = false;

    }
}